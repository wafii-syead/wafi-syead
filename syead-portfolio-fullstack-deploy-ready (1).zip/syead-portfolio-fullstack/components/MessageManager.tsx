"use client";

import { useEffect, useState } from "react";

type Message = {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
};

export function MessageManager() {
  const [messages, setMessages] = useState<Message[]>([]);

  async function load() {
    const response = await fetch("/api/admin/messages");
    const data = await response.json();
    setMessages(data.messages || []);
  }

  useEffect(() => { load(); }, []);

  async function update(id: number, status: string) {
    await fetch(`/api/admin/messages/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    load();
  }

  async function remove(id: number) {
    if (!confirm("Delete this message?")) return;
    await fetch(`/api/admin/messages/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="table-wrap">
      <table className="table">
        <thead><tr><th>Sender</th><th>Subject and message</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {messages.map(item => (
            <tr key={item.id}>
              <td><strong>{item.name}</strong><br /><a href={`mailto:${item.email}`}>{item.email}</a></td>
              <td><strong>{item.subject}</strong><p className="muted">{item.message}</p></td>
              <td>{item.status}</td>
              <td className="actions">
                <button className="btn btn-small" onClick={() => update(item.id, "READ")}>Read</button>
                <button className="btn btn-small" onClick={() => update(item.id, "REPLIED")}>Replied</button>
                <button className="btn btn-danger btn-small" onClick={() => remove(item.id)}>Delete</button>
              </td>
            </tr>
          ))}
          {!messages.length && <tr><td colSpan={4}>No messages yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

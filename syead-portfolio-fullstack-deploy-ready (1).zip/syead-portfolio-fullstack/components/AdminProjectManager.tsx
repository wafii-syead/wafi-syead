"use client";

import { FormEvent, useEffect, useState } from "react";

type Project = {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  description: string;
  objective?: string | null;
  process?: string | null;
  outcome?: string | null;
  tools: string;
  category: string;
  thumbnail?: string | null;
  externalUrl?: string | null;
  status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFeatured: boolean;
};

const empty = {
  title: "",
  slug: "",
  excerpt: "",
  description: "",
  objective: "",
  process: "",
  outcome: "",
  tools: "",
  category: "Branding",
  thumbnail: "",
  externalUrl: "",
  status: "DRAFT",
  isFeatured: false
};

export function AdminProjectManager() {
  const [items, setItems] = useState<Project[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<any>(empty);
  const [notice, setNotice] = useState("");

  async function load() {
    const response = await fetch("/api/admin/projects");
    const data = await response.json();
    setItems(data.projects || []);
  }

  useEffect(() => { load(); }, []);

  async function submit(event: FormEvent) {
    event.preventDefault();
    const response = await fetch(
      editingId ? `/api/admin/projects/${editingId}` : "/api/admin/projects",
      {
        method: editingId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }
    );
    const data = await response.json();
    if (!response.ok) return setNotice(data.error || "Could not save project.");
    setNotice("Project saved.");
    setEditingId(null);
    setForm(empty);
    load();
  }

  function edit(item: Project) {
    setEditingId(item.id);
    setForm({
      ...item,
      objective: item.objective || "",
      process: item.process || "",
      outcome: item.outcome || "",
      thumbnail: item.thumbnail || "",
      externalUrl: item.externalUrl || ""
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function remove(id: number) {
    if (!confirm("Delete this project?")) return;
    await fetch(`/api/admin/projects/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <>
      <form className="card form" onSubmit={submit}>
        <div className="admin-header">
          <div>
            <h2 style={{ margin: 0 }}>{editingId ? "Edit project" : "New project"}</h2>
            <span className="muted">Manage public portfolio work.</span>
          </div>
          {editingId && <button type="button" className="btn btn-small" onClick={() => { setEditingId(null); setForm(empty); }}>Cancel edit</button>}
        </div>
        <div className="form-row">
          <div className="field"><label>Title</label><input className="input" required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></div>
          <div className="field"><label>Slug (optional)</label><input className="input" value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} /></div>
        </div>
        <div className="field"><label>Short summary</label><textarea className="textarea" required value={form.excerpt} onChange={e => setForm({ ...form, excerpt: e.target.value })} /></div>
        <div className="field"><label>Description</label><textarea className="textarea" required value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
        <div className="form-row">
          <div className="field"><label>Objective</label><textarea className="textarea" value={form.objective} onChange={e => setForm({ ...form, objective: e.target.value })} /></div>
          <div className="field"><label>Process</label><textarea className="textarea" value={form.process} onChange={e => setForm({ ...form, process: e.target.value })} /></div>
        </div>
        <div className="field"><label>Outcome</label><textarea className="textarea" value={form.outcome} onChange={e => setForm({ ...form, outcome: e.target.value })} /></div>
        <div className="form-row">
          <div className="field"><label>Category</label><input className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} /></div>
          <div className="field"><label>Tools (comma separated)</label><input className="input" value={form.tools} onChange={e => setForm({ ...form, tools: e.target.value })} /></div>
        </div>
        <div className="form-row">
          <div className="field"><label>Thumbnail URL</label><input className="input" value={form.thumbnail} onChange={e => setForm({ ...form, thumbnail: e.target.value })} /></div>
          <div className="field"><label>External link</label><input className="input" value={form.externalUrl} onChange={e => setForm({ ...form, externalUrl: e.target.value })} /></div>
        </div>
        <div className="field">
          <label>Status</label>
          <select className="select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
            <option value="DRAFT">Draft</option><option value="PUBLISHED">Published</option><option value="ARCHIVED">Archived</option>
          </select>
        </div>
        <label><input type="checkbox" checked={form.isFeatured} onChange={e => setForm({ ...form, isFeatured: e.target.checked })} /> Featured project</label>
        <button className="btn btn-primary">{editingId ? "Update project" : "Create project"}</button>
        {notice && <div className="notice">{notice}</div>}
      </form>

      <div className="section-sm">
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Project</th><th>Category</th><th>Status</th><th>Featured</th><th>Actions</th></tr></thead>
            <tbody>
              {items.map(item => (
                <tr key={item.id}>
                  <td><strong>{item.title}</strong><div className="muted">/{item.slug}</div></td>
                  <td>{item.category}</td><td>{item.status}</td><td>{item.isFeatured ? "Yes" : "No"}</td>
                  <td className="actions">
                    <button className="btn btn-small" onClick={() => edit(item)}>Edit</button>
                    <button className="btn btn-danger btn-small" onClick={() => remove(item.id)}>Delete</button>
                  </td>
                </tr>
              ))}
              {!items.length && <tr><td colSpan={5}>No projects yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

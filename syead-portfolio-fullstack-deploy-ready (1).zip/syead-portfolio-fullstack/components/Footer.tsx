export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-row">
        <span>© {new Date().getFullYear()} Syead Afridi Wafi</span>
        <span>Designed &amp; Developed by Wafii Syead</span>
      </div>
    </footer>
  );
}

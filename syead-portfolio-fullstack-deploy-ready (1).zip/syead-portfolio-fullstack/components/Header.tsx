import Link from "next/link";
import { ThemeToggle } from "./ThemeToggle";

export function Header() {
  return (
    <header className="nav">
      <div className="container nav-inner">
        <Link className="brand" href="/">
          Wafii<span>.</span>
        </Link>
        <nav className="nav-links" aria-label="Main navigation">
          <Link href="/#about">About</Link>
          <Link href="/#skills">Skills</Link>
          <Link href="/portfolio">Portfolio</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/#contact">Contact</Link>
        </nav>
        <div className="nav-actions">
          <ThemeToggle />
          <Link className="btn btn-primary btn-small" href="/admin/login">Admin</Link>
        </div>
      </div>
    </header>
  );
}

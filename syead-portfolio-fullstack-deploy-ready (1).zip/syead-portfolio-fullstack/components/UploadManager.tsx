"use client";

import { FormEvent, useEffect, useState } from "react";

type Media = {
  id: number;
  originalName: string;
  url: string;
  mimeType: string;
  sizeBytes: number;
  createdAt: string;
};

export function UploadManager() {
  const [media, setMedia] = useState<Media[]>([]);
  const [notice, setNotice] = useState("");

  async function load() {
    const response = await fetch("/api/admin/media");
    const data = await response.json();
    setMedia(data.media || []);
  }

  useEffect(() => { load(); }, []);

  async function upload(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setNotice("Uploading...");
    const response = await fetch("/api/admin/media", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) return setNotice(data.error || "Upload failed.");
    setNotice(`Uploaded: ${data.media.url}`);
    event.currentTarget.reset();
    load();
  }

  async function remove(id: number) {
    if (!confirm("Delete this file record and uploaded file?")) return;
    await fetch(`/api/admin/media/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <>
      <form className="card form" onSubmit={upload}>
        <h2 style={{ margin: 0 }}>Upload media</h2>
        <p className="muted">Images up to 8 MB and PDF documents up to 15 MB.</p>
        <div className="field"><label>File</label><input className="input" type="file" name="file" required accept="image/jpeg,image/png,image/webp,image/gif,application/pdf" /></div>
        <div className="form-row">
          <div className="field"><label>Alt text</label><input className="input" name="altText" /></div>
          <div className="field"><label>Caption</label><input className="input" name="caption" /></div>
        </div>
        <button className="btn btn-primary">Upload</button>
        {notice && <div className="notice">{notice}</div>}
      </form>
      <div className="section-sm grid grid-3">
        {media.map(item => (
          <div className="card" key={item.id}>
            {item.mimeType.startsWith("image/") ? <img className="cover" src={item.url} alt={item.originalName} /> : <div className="cover" style={{ display: "grid", placeItems: "center" }}>PDF</div>}
            <strong>{item.originalName}</strong>
            <div className="muted">{Math.round(item.sizeBytes / 1024)} KB</div>
            <div className="actions" style={{ marginTop: 14 }}>
              <button className="btn btn-small" onClick={() => navigator.clipboard.writeText(item.url)}>Copy URL</button>
              <button className="btn btn-danger btn-small" onClick={() => remove(item.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

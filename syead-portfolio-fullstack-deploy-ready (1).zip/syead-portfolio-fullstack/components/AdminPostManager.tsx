"use client";

import { FormEvent, useEffect, useState } from "react";

type Post = {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string;
  status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFeatured: boolean;
  coverImage?: string | null;
};

const empty = {
  title: "",
  slug: "",
  excerpt: "",
  content: "",
  category: "Design",
  tags: "",
  status: "DRAFT",
  isFeatured: false,
  coverImage: ""
};

export function AdminPostManager() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<any>(empty);
  const [notice, setNotice] = useState("");

  async function load() {
    const response = await fetch("/api/admin/posts");
    const data = await response.json();
    setPosts(data.posts || []);
  }

  useEffect(() => { load(); }, []);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setNotice("");
    const response = await fetch(
      editingId ? `/api/admin/posts/${editingId}` : "/api/admin/posts",
      {
        method: editingId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      }
    );
    const data = await response.json();
    if (!response.ok) return setNotice(data.error || "Could not save post.");
    setNotice("Post saved.");
    setEditingId(null);
    setForm(empty);
    load();
  }

  function edit(post: Post) {
    setEditingId(post.id);
    setForm({ ...post, coverImage: post.coverImage || "" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function remove(id: number) {
    if (!confirm("Delete this post?")) return;
    await fetch(`/api/admin/posts/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <>
      <form className="card form" onSubmit={submit}>
        <div className="admin-header">
          <div>
            <h2 style={{ margin: 0 }}>{editingId ? "Edit article" : "New article"}</h2>
            <span className="muted">Create, draft and publish blog content.</span>
          </div>
          {editingId && (
            <button type="button" className="btn btn-small" onClick={() => { setEditingId(null); setForm(empty); }}>
              Cancel edit
            </button>
          )}
        </div>
        <div className="form-row">
          <div className="field">
            <label>Title</label>
            <input className="input" required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
          </div>
          <div className="field">
            <label>Slug (optional)</label>
            <input className="input" value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} />
          </div>
        </div>
        <div className="field">
          <label>Excerpt</label>
          <textarea className="textarea" required value={form.excerpt} onChange={e => setForm({ ...form, excerpt: e.target.value })} />
        </div>
        <div className="field">
          <label>Article content</label>
          <textarea className="textarea" style={{ minHeight: 300 }} required value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} />
        </div>
        <div className="form-row">
          <div className="field">
            <label>Category</label>
            <input className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} />
          </div>
          <div className="field">
            <label>Tags (comma separated)</label>
            <input className="input" value={form.tags} onChange={e => setForm({ ...form, tags: e.target.value })} />
          </div>
        </div>
        <div className="form-row">
          <div className="field">
            <label>Status</label>
            <select className="select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
              <option value="DRAFT">Draft</option>
              <option value="PUBLISHED">Published</option>
              <option value="ARCHIVED">Archived</option>
            </select>
          </div>
          <div className="field">
            <label>Cover image URL</label>
            <input className="input" value={form.coverImage} onChange={e => setForm({ ...form, coverImage: e.target.value })} placeholder="/uploads/example.webp" />
          </div>
        </div>
        <label><input type="checkbox" checked={form.isFeatured} onChange={e => setForm({ ...form, isFeatured: e.target.checked })} /> Featured article</label>
        <button className="btn btn-primary">{editingId ? "Update article" : "Create article"}</button>
        {notice && <div className="notice">{notice}</div>}
      </form>

      <div className="section-sm">
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Title</th><th>Category</th><th>Status</th><th>Featured</th><th>Actions</th></tr></thead>
            <tbody>
              {posts.map(post => (
                <tr key={post.id}>
                  <td><strong>{post.title}</strong><div className="muted">/{post.slug}</div></td>
                  <td>{post.category}</td>
                  <td>{post.status}</td>
                  <td>{post.isFeatured ? "Yes" : "No"}</td>
                  <td className="actions">
                    <button className="btn btn-small" onClick={() => edit(post)}>Edit</button>
                    <button className="btn btn-danger btn-small" onClick={() => remove(post.id)}>Delete</button>
                  </td>
                </tr>
              ))}
              {!posts.length && <tr><td colSpan={5}>No posts yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

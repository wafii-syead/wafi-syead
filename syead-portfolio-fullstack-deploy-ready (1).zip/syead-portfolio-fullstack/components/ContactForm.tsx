"use client";

import { FormEvent, useState } from "react";

export function ContactForm() {
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSending(true);
    setMessage("");
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const response = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    setSending(false);
    setMessage(response.ok ? "Message sent successfully." : data.error || "Could not send message.");
    if (response.ok) event.currentTarget.reset();
  }

  return (
    <form className="form card" onSubmit={submit}>
      <div className="form-row">
        <div className="field">
          <label htmlFor="name">Name</label>
          <input className="input" id="name" name="name" required minLength={2} />
        </div>
        <div className="field">
          <label htmlFor="email">Email</label>
          <input className="input" id="email" name="email" type="email" required />
        </div>
      </div>
      <div className="field">
        <label htmlFor="subject">Subject</label>
        <input className="input" id="subject" name="subject" required minLength={3} />
      </div>
      <div className="field">
        <label htmlFor="message">Message</label>
        <textarea className="textarea" id="message" name="message" required minLength={10} />
      </div>
      <button className="btn btn-primary" disabled={sending}>
        {sending ? "Sending..." : "Send Message"}
      </button>
      {message && <div className="notice">{message}</div>}
    </form>
  );
}

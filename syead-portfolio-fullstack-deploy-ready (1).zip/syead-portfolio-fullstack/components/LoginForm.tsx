"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export function LoginForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(Object.fromEntries(form.entries()))
    });
    const data = await response.json();
    setLoading(false);
    if (!response.ok) return setError(data.error || "Login failed.");
    router.push("/admin");
    router.refresh();
  }

  return (
    <form className="form" onSubmit={login}>
      <div className="field"><label>Email</label><input className="input" name="email" type="email" required /></div>
      <div className="field"><label>Password</label><input className="input" name="password" type="password" required /></div>
      <button className="btn btn-primary" disabled={loading}>{loading ? "Signing in..." : "Sign in"}</button>
      {error && <div className="notice">{error}</div>}
    </form>
  );
}

#!/usr/bin/env bash
set -euo pipefail

DATA_DIR="${DATA_DIR:-/var/data}"
UPLOAD_DIR="$DATA_DIR/uploads"
PUBLIC_UPLOAD_LINK="$(pwd)/public/uploads"

mkdir -p "$UPLOAD_DIR"
rm -rf "$PUBLIC_UPLOAD_LINK"
ln -s "$UPLOAD_DIR" "$PUBLIC_UPLOAD_LINK"

npx prisma db push
npm run seed
exec npm start

import bcrypt from "bcryptjs";
import { PrismaClient, Role, ContentStatus } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const name = process.env.ADMIN_NAME || "Syead Afridi Wafi";
  const email = process.env.ADMIN_EMAIL || "get.syeadafridi@gmail.com";
  const password = process.env.ADMIN_PASSWORD || "change-this-password";
  const passwordHash = await bcrypt.hash(password, 12);

  await prisma.user.upsert({
    where: { email },
    update: { name, passwordHash, role: Role.SUPER_ADMIN, isActive: true },
    create: { name, email, passwordHash, role: Role.SUPER_ADMIN }
  });

  await prisma.post.upsert({
    where: { slug: "building-meaningful-digital-experiences" },
    update: {},
    create: {
      title: "Building Meaningful Digital Experiences",
      slug: "building-meaningful-digital-experiences",
      excerpt: "How research, design and strategy can work together to create better digital products.",
      content: "Great digital work begins with understanding people.\n\nI combine research, visual design and content strategy to build experiences that are clear, useful and memorable.\n\nThis portfolio is designed to grow with my work, ideas and professional journey.",
      category: "Design",
      tags: "design,research,strategy",
      status: ContentStatus.PUBLISHED,
      isFeatured: true,
      publishedAt: new Date()
    }
  });

  await prisma.project.upsert({
    where: { slug: "mocktestforielts-brand-content" },
    update: {},
    create: {
      title: "MockTestForIELTS Brand Content",
      slug: "mocktestforielts-brand-content",
      excerpt: "A collection of educational campaigns, social content and product-focused visual communication.",
      description: "Brand and content design work created for an IELTS preparation platform.",
      objective: "Build a clear, modern and recognisable visual system for students and educators.",
      process: "Research audience needs, simplify the message, create visual directions and refine through feedback.",
      outcome: "A consistent set of promotional, educational and product communication assets.",
      tools: "Canva,Adobe Creative Tools,AI-Assisted Design",
      category: "Educational Design",
      status: ContentStatus.PUBLISHED,
      isFeatured: true,
      publishedAt: new Date()
    }
  });

  console.log(`Seed complete. Admin email: ${email}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => prisma.$disconnect());

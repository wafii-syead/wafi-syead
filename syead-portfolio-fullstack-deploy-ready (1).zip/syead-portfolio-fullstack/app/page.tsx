import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { csvToArray, formatDate, readingTime } from "@/lib/utils";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ContactForm } from "@/components/ContactForm";

const skills = [
  "Graphic Design", "Branding", "Social Media Design", "Website Design",
  "UI/UX Design", "Content Creation", "Research & Development",
  "Digital Marketing", "Creative Strategy", "Blog Writing",
  "Canva", "Adobe Creative Tools", "AI-Assisted Design"
];

const services = [
  ["Graphic Design", "Clear and purposeful visual communication for digital and print."],
  ["Brand Identity", "Consistent visual systems that make brands recognisable."],
  ["Social Media Content", "Campaign assets designed for engagement and clarity."],
  ["Website Design", "Responsive interfaces and landing pages with strong hierarchy."],
  ["Content & Blog", "Useful, structured and audience-focused digital content."],
  ["Research & Strategy", "Insight-led creative direction and product communication."]
];

export default async function HomePage() {
  const [projects, posts] = await Promise.all([
    prisma.project.findMany({ where: { status: "PUBLISHED" }, orderBy: { publishedAt: "desc" }, take: 3 }),
    prisma.post.findMany({ where: { status: "PUBLISHED" }, orderBy: { publishedAt: "desc" }, take: 3 })
  ]);

  return (
    <>
      <Header />
      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div>
              <div className="eyebrow">Research · Design · Strategy</div>
              <h1 className="display">Hi, I’m <span className="accent">Syead Afridi Wafi.</span></h1>
              <p className="lead">I create meaningful digital experiences through design, branding, research and creative strategy.</p>
              <div className="hero-actions">
                <Link className="btn btn-primary" href="/portfolio">View My Work</Link>
                <Link className="btn" href="/#contact">Contact Me</Link>
              </div>
            </div>
            <div className="hero-card">
              <div>
                <span className="badge">R&amp;D Manager</span>
                <h2 style={{ fontSize: "2rem", marginBottom: 0 }}>MockTestForIELTS</h2>
                <p className="muted">Product thinking, brand communication and educational design.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="about">
          <div className="container grid grid-2">
            <div>
              <div className="eyebrow">About</div>
              <h2 className="h2">Creative work grounded in research.</h2>
            </div>
            <div>
              <p className="lead">I work across research and development, graphic design, branding, digital content and website design.</p>
              <p className="muted">At MockTestForIELTS, I contribute to product development, branding, promotional design, content strategy and digital experiences for learners and educators.</p>
              <a className="btn" href="mailto:get.syeadafridi@gmail.com">get.syeadafridi@gmail.com</a>
            </div>
          </div>
        </section>

        <section className="section" id="skills">
          <div className="container">
            <div className="eyebrow">Skills</div>
            <h2 className="h2">What I work with</h2>
            <div className="tags">
              {skills.map(skill => <span className="badge" key={skill}>{skill}</span>)}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="eyebrow">Services</div>
            <h2 className="h2">How I can contribute</h2>
            <div className="grid grid-3">
              {services.map(([title, description]) => (
                <div className="card" key={title}><h3>{title}</h3><p className="muted">{description}</p></div>
              ))}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="admin-header">
              <div><div className="eyebrow">Selected work</div><h2 className="h2">Featured projects</h2></div>
              <Link className="btn" href="/portfolio">All projects</Link>
            </div>
            <div className="grid grid-3">
              {projects.map(project => (
                <Link className="card" href={`/portfolio/${project.slug}`} key={project.id}>
                  {project.thumbnail && <img className="cover" src={project.thumbnail} alt={project.title} />}
                  <span className="badge">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p className="muted">{project.excerpt}</p>
                  <div className="tags">{csvToArray(project.tools).slice(0, 3).map(tool => <span key={tool}>{tool}</span>)}</div>
                </Link>
              ))}
              {!projects.length && <div className="card">Publish projects from the admin panel.</div>}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="admin-header">
              <div><div className="eyebrow">Writing</div><h2 className="h2">Latest articles</h2></div>
              <Link className="btn" href="/blog">All articles</Link>
            </div>
            <div className="grid grid-3">
              {posts.map(post => (
                <Link className="card" href={`/blog/${post.slug}`} key={post.id}>
                  {post.coverImage && <img className="cover" src={post.coverImage} alt={post.title} />}
                  <span className="badge">{post.category}</span>
                  <h3>{post.title}</h3>
                  <p className="muted">{post.excerpt}</p>
                  <small className="muted">{formatDate(post.publishedAt)} · {readingTime(post.content)} min read</small>
                </Link>
              ))}
              {!posts.length && <div className="card">Publish posts from the admin panel.</div>}
            </div>
          </div>
        </section>

        <section className="section" id="contact">
          <div className="container grid grid-2">
            <div>
              <div className="eyebrow">Contact</div>
              <h2 className="h2">Let’s create something meaningful.</h2>
              <p className="lead">Have a project, collaboration or creative idea? Send me a message.</p>
            </div>
            <ContactForm />
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

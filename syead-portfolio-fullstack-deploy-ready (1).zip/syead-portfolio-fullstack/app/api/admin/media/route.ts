import crypto from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const allowed = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"]);

export async function GET(request: NextRequest) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const media = await prisma.media.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json({ media });
}

export async function POST(request: NextRequest) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const data = await request.formData();
    const file = data.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "Select a file." }, { status: 400 });
    if (!allowed.has(file.type)) return NextResponse.json({ error: "Unsupported file type." }, { status: 400 });

    const max = file.type === "application/pdf" ? 15 * 1024 * 1024 : 8 * 1024 * 1024;
    if (file.size > max) return NextResponse.json({ error: "The file is too large." }, { status: 400 });

    const extension = path.extname(file.name).toLowerCase().replace(/[^.a-z0-9]/g, "");
    const storedName = `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${extension}`;
    const directory = path.join(process.cwd(), "public", "uploads");
    await mkdir(directory, { recursive: true });
    await writeFile(path.join(directory, storedName), Buffer.from(await file.arrayBuffer()));

    const media = await prisma.media.create({
      data: {
        originalName: file.name,
        storedName,
        url: `/uploads/${storedName}`,
        mimeType: file.type,
        sizeBytes: file.size,
        altText: String(data.get("altText") || "") || null,
        caption: String(data.get("caption") || "") || null
      }
    });

    return NextResponse.json({ media }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Upload failed." }, { status: 500 });
  }
}

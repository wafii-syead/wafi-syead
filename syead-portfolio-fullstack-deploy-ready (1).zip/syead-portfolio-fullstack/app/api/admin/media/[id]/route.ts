import { unlink } from "fs/promises";
import path from "path";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const media = await prisma.media.findUnique({ where: { id: Number(id) } });
  if (!media) return NextResponse.json({ error: "File not found." }, { status: 404 });

  try {
    await unlink(path.join(process.cwd(), "public", "uploads", media.storedName));
  } catch {
    // The database record can still be deleted if the local file is already missing.
  }
  await prisma.media.delete({ where: { id: media.id } });
  return NextResponse.json({ ok: true });
}

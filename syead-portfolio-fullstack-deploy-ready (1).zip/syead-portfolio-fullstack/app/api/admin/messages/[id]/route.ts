import { MessageStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const body = await request.json();
  const status = Object.values(MessageStatus).includes(body.status) ? body.status : MessageStatus.READ;
  const message = await prisma.contactMessage.update({ where: { id: Number(id) }, data: { status } });
  return NextResponse.json({ message });
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await prisma.contactMessage.delete({ where: { id: Number(id) } });
  return NextResponse.json({ ok: true });
}

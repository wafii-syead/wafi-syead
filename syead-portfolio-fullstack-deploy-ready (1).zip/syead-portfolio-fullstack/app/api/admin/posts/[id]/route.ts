import { ContentStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const body = await request.json();
    const status = Object.values(ContentStatus).includes(body.status) ? body.status : ContentStatus.DRAFT;
    const existing = await prisma.post.findUnique({ where: { id: Number(id) } });
    if (!existing) return NextResponse.json({ error: "Post not found." }, { status: 404 });

    const post = await prisma.post.update({
      where: { id: Number(id) },
      data: {
        title: String(body.title || existing.title).trim(),
        slug: slugify(body.slug || body.title || existing.slug),
        excerpt: String(body.excerpt ?? existing.excerpt).trim(),
        content: String(body.content ?? existing.content).trim(),
        category: String(body.category ?? existing.category).trim(),
        tags: String(body.tags ?? existing.tags).trim(),
        coverImage: body.coverImage ? String(body.coverImage) : null,
        status,
        isFeatured: Boolean(body.isFeatured),
        publishedAt: status === ContentStatus.PUBLISHED ? (existing.publishedAt || new Date()) : null
      }
    });
    return NextResponse.json({ post });
  } catch {
    return NextResponse.json({ error: "Could not update post. Check that the slug is unique." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await prisma.post.delete({ where: { id: Number(id) } });
  return NextResponse.json({ ok: true });
}

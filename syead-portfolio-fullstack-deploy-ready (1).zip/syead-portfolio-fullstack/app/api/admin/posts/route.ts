import { ContentStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";

export async function GET(request: NextRequest) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const posts = await prisma.post.findMany({ orderBy: { updatedAt: "desc" } });
  return NextResponse.json({ posts });
}

export async function POST(request: NextRequest) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const title = String(body.title || "").trim();
    const content = String(body.content || "").trim();
    if (!title || !content) return NextResponse.json({ error: "Title and content are required." }, { status: 400 });

    const slug = slugify(body.slug || title);
    const exists = await prisma.post.findUnique({ where: { slug } });
    if (exists) return NextResponse.json({ error: "This slug already exists." }, { status: 409 });

    const status = Object.values(ContentStatus).includes(body.status) ? body.status : ContentStatus.DRAFT;
    const post = await prisma.post.create({
      data: {
        title,
        slug,
        excerpt: String(body.excerpt || "").trim(),
        content,
        category: String(body.category || "Uncategorized").trim(),
        tags: String(body.tags || "").trim(),
        coverImage: body.coverImage ? String(body.coverImage) : null,
        status,
        isFeatured: Boolean(body.isFeatured),
        publishedAt: status === ContentStatus.PUBLISHED ? new Date() : null
      }
    });
    return NextResponse.json({ post }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create post." }, { status: 500 });
  }
}

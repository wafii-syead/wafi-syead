import { ContentStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";

export async function GET(request: NextRequest) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const projects = await prisma.project.findMany({ orderBy: { updatedAt: "desc" } });
  return NextResponse.json({ projects });
}

export async function POST(request: NextRequest) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const title = String(body.title || "").trim();
    const description = String(body.description || "").trim();
    if (!title || !description) return NextResponse.json({ error: "Title and description are required." }, { status: 400 });

    const slug = slugify(body.slug || title);
    const status = Object.values(ContentStatus).includes(body.status) ? body.status : ContentStatus.DRAFT;
    const project = await prisma.project.create({
      data: {
        title, slug,
        excerpt: String(body.excerpt || "").trim(),
        description,
        objective: body.objective ? String(body.objective) : null,
        process: body.process ? String(body.process) : null,
        outcome: body.outcome ? String(body.outcome) : null,
        tools: String(body.tools || ""),
        category: String(body.category || "Creative Projects"),
        thumbnail: body.thumbnail ? String(body.thumbnail) : null,
        externalUrl: body.externalUrl ? String(body.externalUrl) : null,
        status,
        isFeatured: Boolean(body.isFeatured),
        publishedAt: status === ContentStatus.PUBLISHED ? new Date() : null
      }
    });
    return NextResponse.json({ project }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create project. Check that the slug is unique." }, { status: 500 });
  }
}

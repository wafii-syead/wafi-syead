import { ContentStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { getRequestSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const body = await request.json();
    const existing = await prisma.project.findUnique({ where: { id: Number(id) } });
    if (!existing) return NextResponse.json({ error: "Project not found." }, { status: 404 });
    const status = Object.values(ContentStatus).includes(body.status) ? body.status : ContentStatus.DRAFT;

    const project = await prisma.project.update({
      where: { id: Number(id) },
      data: {
        title: String(body.title || existing.title).trim(),
        slug: slugify(body.slug || body.title || existing.slug),
        excerpt: String(body.excerpt ?? existing.excerpt).trim(),
        description: String(body.description ?? existing.description).trim(),
        objective: body.objective ? String(body.objective) : null,
        process: body.process ? String(body.process) : null,
        outcome: body.outcome ? String(body.outcome) : null,
        tools: String(body.tools ?? existing.tools),
        category: String(body.category ?? existing.category),
        thumbnail: body.thumbnail ? String(body.thumbnail) : null,
        externalUrl: body.externalUrl ? String(body.externalUrl) : null,
        status,
        isFeatured: Boolean(body.isFeatured),
        publishedAt: status === ContentStatus.PUBLISHED ? (existing.publishedAt || new Date()) : null
      }
    });
    return NextResponse.json({ project });
  } catch {
    return NextResponse.json({ error: "Could not update project. Check that the slug is unique." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!getRequestSession(request)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await prisma.project.delete({ where: { id: Number(id) } });
  return NextResponse.json({ ok: true });
}

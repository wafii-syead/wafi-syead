import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const name = String(body.name || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const subject = String(body.subject || "").trim();
    const message = String(body.message || "").trim();

    if (name.length < 2 || !email.includes("@") || subject.length < 3 || message.length < 10) {
      return NextResponse.json({ error: "Please complete every field correctly." }, { status: 400 });
    }

    await prisma.contactMessage.create({ data: { name, email, subject, message } });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not save your message." }, { status: 500 });
  }
}

import bcrypt from "bcryptjs";
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSessionToken, sessionCookie } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json();
    if (!email || !password) return NextResponse.json({ error: "Email and password are required." }, { status: 400 });

    const user = await prisma.user.findUnique({ where: { email: String(email).toLowerCase() } });
    if (!user || !user.isActive) return NextResponse.json({ error: "Invalid login details." }, { status: 401 });

    const valid = await bcrypt.compare(String(password), user.passwordHash);
    if (!valid) return NextResponse.json({ error: "Invalid login details." }, { status: 401 });

    const token = createSessionToken({ userId: user.id, email: user.email, role: user.role });
    const response = NextResponse.json({ ok: true, user: { name: user.name, email: user.email, role: user.role } });
    response.cookies.set(sessionCookie.name, token, sessionCookie.options);
    return response;
  } catch {
    return NextResponse.json({ error: "Login failed." }, { status: 500 });
  }
}

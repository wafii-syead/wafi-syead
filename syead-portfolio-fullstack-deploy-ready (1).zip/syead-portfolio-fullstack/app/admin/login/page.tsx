import Link from "next/link";
import { LoginForm } from "@/components/LoginForm";

export const metadata = { title: "Admin Login" };

export default function AdminLoginPage() {
  return (
    <main className="login-page">
      <div className="login-card">
        <div className="eyebrow">Portfolio CMS</div>
        <h1>Admin login</h1>
        <p style={{ color: "#aaa" }}>Manage your blog, portfolio, media and messages.</p>
        <LoginForm />
        <p><Link href="/">← Back to website</Link></p>
      </div>
    </main>
  );
}

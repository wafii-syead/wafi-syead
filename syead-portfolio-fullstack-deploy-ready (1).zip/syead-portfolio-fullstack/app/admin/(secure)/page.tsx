import { prisma } from "@/lib/prisma";

export default async function AdminDashboard() {
  const [posts, projects, media, unread] = await Promise.all([
    prisma.post.count(),
    prisma.project.count(),
    prisma.media.count(),
    prisma.contactMessage.count({ where: { status: "UNREAD" } })
  ]);

  return (
    <>
      <div className="admin-header">
        <div><div className="eyebrow">Overview</div><h1 style={{ margin: 0 }}>Dashboard</h1></div>
      </div>
      <div className="grid grid-3">
        <div className="card"><div className="stat">{posts}</div><span className="muted">Blog posts</span></div>
        <div className="card"><div className="stat">{projects}</div><span className="muted">Portfolio projects</span></div>
        <div className="card"><div className="stat">{media}</div><span className="muted">Media files</span></div>
        <div className="card"><div className="stat">{unread}</div><span className="muted">Unread messages</span></div>
      </div>
      <div className="section-sm card">
        <h2>Admin capabilities</h2>
        <p className="muted">Create and publish articles, manage projects, upload images or CV PDFs, review contact messages and control what appears on the public website.</p>
      </div>
    </>
  );
}

import { AdminProjectManager } from "@/components/AdminProjectManager";

export default function AdminProjectsPage() {
  return (
    <>
      <div className="admin-header"><div><div className="eyebrow">Work</div><h1 style={{ margin: 0 }}>Project manager</h1></div></div>
      <AdminProjectManager />
    </>
  );
}

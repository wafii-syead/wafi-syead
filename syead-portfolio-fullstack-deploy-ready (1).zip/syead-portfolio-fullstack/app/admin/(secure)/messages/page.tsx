import { MessageManager } from "@/components/MessageManager";

export default function AdminMessagesPage() {
  return (
    <>
      <div className="admin-header"><div><div className="eyebrow">Inbox</div><h1 style={{ margin: 0 }}>Contact messages</h1></div></div>
      <MessageManager />
    </>
  );
}

import { UploadManager } from "@/components/UploadManager";

export default function AdminMediaPage() {
  return (
    <>
      <div className="admin-header"><div><div className="eyebrow">Assets</div><h1 style={{ margin: 0 }}>Media library</h1></div></div>
      <UploadManager />
    </>
  );
}

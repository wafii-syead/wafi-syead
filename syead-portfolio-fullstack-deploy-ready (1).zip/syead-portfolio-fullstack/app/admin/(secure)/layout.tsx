import Link from "next/link";
import { requireAdminPage } from "@/lib/auth";
import { LogoutButton } from "@/components/LogoutButton";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireAdminPage();

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <Link className="brand" href="/admin">Wafii<span>.</span> CMS</Link>
        <p style={{ color: "#999" }}>{session.email}</p>
        <nav>
          <Link href="/admin">Dashboard</Link>
          <Link href="/admin/posts">Blog posts</Link>
          <Link href="/admin/projects">Projects</Link>
          <Link href="/admin/media">Media</Link>
          <Link href="/admin/messages">Messages</Link>
          <Link href="/" target="_blank">View website</Link>
        </nav>
        <div style={{ marginTop: 24 }}><LogoutButton /></div>
      </aside>
      <main className="admin-main">{children}</main>
    </div>
  );
}

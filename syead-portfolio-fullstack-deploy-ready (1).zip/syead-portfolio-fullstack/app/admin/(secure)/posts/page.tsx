import { AdminPostManager } from "@/components/AdminPostManager";

export default function AdminPostsPage() {
  return (
    <>
      <div className="admin-header"><div><div className="eyebrow">Content</div><h1 style={{ margin: 0 }}>Blog manager</h1></div></div>
      <AdminPostManager />
    </>
  );
}

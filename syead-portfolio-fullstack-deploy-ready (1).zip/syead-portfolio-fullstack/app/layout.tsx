import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Syead Afridi Wafi | Portfolio",
    template: "%s | Syead Afridi Wafi"
  },
  description: "Research, design, branding and digital content portfolio of Syead Afridi Wafi."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" data-theme="dark">
      <body>{children}</body>
    </html>
  );
}

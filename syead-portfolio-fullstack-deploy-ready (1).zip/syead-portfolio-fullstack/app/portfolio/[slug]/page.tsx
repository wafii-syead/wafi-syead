import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { csvToArray } from "@/lib/utils";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const item = await prisma.project.findUnique({ where: { slug } });
  if (!item) return {};
  return {
    title: item.seoTitle || item.title,
    description: item.seoDescription || item.excerpt
  };
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = await prisma.project.findFirst({ where: { slug, status: "PUBLISHED" } });
  if (!project) notFound();

  const gallery = (() => {
    try { return JSON.parse(project.gallery) as string[]; } catch { return []; }
  })();

  return (
    <>
      <Header />
      <main className="section">
        <article className="container article">
          <span className="badge">{project.category}</span>
          <h1 className="h1">{project.title}</h1>
          <p className="lead">{project.excerpt}</p>
          {project.thumbnail && <img className="cover" style={{ marginTop: 28 }} src={project.thumbnail} alt={project.title} />}
          <div className="article-content">
            <h2>Overview</h2><p>{project.description}</p>
            {project.objective && <><h2>Objective</h2><p>{project.objective}</p></>}
            {project.process && <><h2>Process</h2><p>{project.process}</p></>}
            {project.outcome && <><h2>Outcome</h2><p>{project.outcome}</p></>}
          </div>
          <div className="tags">{csvToArray(project.tools).map(tool => <span className="badge" key={tool}>{tool}</span>)}</div>
          {gallery.length > 0 && <div className="section-sm grid grid-2">{gallery.map(url => <img className="cover" key={url} src={url} alt={project.title} />)}</div>}
          {project.externalUrl && <a className="btn btn-primary" href={project.externalUrl} target="_blank" rel="noreferrer">Open project</a>}
        </article>
      </main>
      <Footer />
    </>
  );
}

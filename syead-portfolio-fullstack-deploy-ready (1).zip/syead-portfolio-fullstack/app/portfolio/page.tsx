import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { csvToArray } from "@/lib/utils";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Portfolio" };

export default async function PortfolioPage() {
  const projects = await prisma.project.findMany({
    where: { status: "PUBLISHED" },
    orderBy: [{ isFeatured: "desc" }, { publishedAt: "desc" }]
  });

  return (
    <>
      <Header />
      <main className="section">
        <div className="container">
          <div className="eyebrow">Selected projects</div>
          <h1 className="h1">Portfolio</h1>
          <p className="lead">Branding, social media, website design, educational campaigns and creative projects.</p>
          <div className="section-sm grid grid-3">
            {projects.map(project => (
              <Link className="card" href={`/portfolio/${project.slug}`} key={project.id}>
                {project.thumbnail && <img className="cover" src={project.thumbnail} alt={project.title} />}
                <span className="badge">{project.category}</span>
                <h2>{project.title}</h2>
                <p className="muted">{project.excerpt}</p>
                <div className="tags">{csvToArray(project.tools).slice(0, 4).map(tool => <span key={tool}>{tool}</span>)}</div>
              </Link>
            ))}
            {!projects.length && <div className="card">No published projects yet.</div>}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

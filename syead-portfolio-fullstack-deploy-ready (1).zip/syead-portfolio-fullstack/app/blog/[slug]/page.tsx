import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { csvToArray, formatDate, readingTime } from "@/lib/utils";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await prisma.post.findUnique({ where: { slug } });
  if (!post) return {};
  return {
    title: post.seoTitle || post.title,
    description: post.seoDescription || post.excerpt
  };
}

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await prisma.post.findFirst({ where: { slug, status: "PUBLISHED" } });
  if (!post) notFound();

  return (
    <>
      <Header />
      <main className="section">
        <article className="container article">
          <span className="badge">{post.category}</span>
          <h1 className="h1">{post.title}</h1>
          <p className="lead">{post.excerpt}</p>
          <p className="muted">{formatDate(post.publishedAt)} · {readingTime(post.content)} min read</p>
          {post.coverImage && <img className="cover" style={{ marginTop: 28 }} src={post.coverImage} alt={post.title} />}
          <div className="article-content">
            {post.content.split(/\n{2,}/).map((paragraph, index) => <p key={index}>{paragraph}</p>)}
          </div>
          <div className="tags">{csvToArray(post.tags).map(tag => <span className="badge" key={tag}>{tag}</span>)}</div>
        </article>
      </main>
      <Footer />
    </>
  );
}

import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatDate, readingTime } from "@/lib/utils";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata = { title: "Blog" };

export default async function BlogPage() {
  const posts = await prisma.post.findMany({
    where: { status: "PUBLISHED" },
    orderBy: [{ isFeatured: "desc" }, { publishedAt: "desc" }]
  });

  return (
    <>
      <Header />
      <main className="section">
        <div className="container">
          <div className="eyebrow">Ideas and insights</div>
          <h1 className="h1">Blog</h1>
          <p className="lead">Writing about design, branding, technology, research, career and creativity.</p>
          <div className="section-sm grid grid-3">
            {posts.map(post => (
              <Link className="card" href={`/blog/${post.slug}`} key={post.id}>
                {post.coverImage && <img className="cover" src={post.coverImage} alt={post.title} />}
                <span className="badge">{post.category}</span>
                <h2>{post.title}</h2>
                <p className="muted">{post.excerpt}</p>
                <small className="muted">{formatDate(post.publishedAt)} · {readingTime(post.content)} min read</small>
              </Link>
            ))}
            {!posts.length && <div className="card">No published posts yet.</div>}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
